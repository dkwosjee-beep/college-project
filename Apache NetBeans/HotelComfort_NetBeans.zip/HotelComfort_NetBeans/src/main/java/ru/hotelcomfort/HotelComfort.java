package ru.hotelcomfort;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.*;

/**
 * Учебное приложение для практики Apache NetBeans.
 * Тематика: информационная система гостиницы Hotel Comfort.
 * Логотип и сцена отрисовываются средствами Java2D, анимация выполняется Timer.
 */
public class HotelComfort extends JFrame {
    private final JLabel statusLabel = new JLabel("Добро пожаловать! Выберите действие.");
    private final ScenePanel scenePanel = new ScenePanel();

    public HotelComfort() {
        setTitle("Hotel Comfort — информационная система гостиницы");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 620));
        setSize(1100, 720);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(new Color(18, 34, 54));

        JPanel header = new JPanel(new BorderLayout(18, 0));
        header.setBorder(BorderFactory.createEmptyBorder(14, 22, 14, 22));
        header.setBackground(new Color(18, 34, 54));

        JLabel logo = new JLabel("  HOTEL COMFORT");
        logo.setForeground(new Color(245, 213, 148));
        logo.setFont(new Font("SansSerif", Font.BOLD, 25));
        header.add(logo, BorderLayout.WEST);

        JLabel subtitle = new JLabel("ИНФОРМАЦИОННАЯ СИСТЕМА ГОСТИНИЦЫ");
        subtitle.setForeground(new Color(220, 229, 238));
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        header.add(subtitle, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        scenePanel.setPreferredSize(new Dimension(900, 470));
        root.add(scenePanel, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(12, 8));
        bottom.setBorder(BorderFactory.createEmptyBorder(12, 18, 14, 18));
        bottom.setBackground(new Color(245, 247, 250));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        buttons.setOpaque(false);

        JButton roomsButton = makeButton("Номера и цены");
        roomsButton.addActionListener((ActionEvent e) ->
                showMessage("Номера и цены", "Стандарт — 3 500 руб./сутки\\Полулюкс — 5 000 руб./сутки\\Люкс — 7 500 руб./сутки\\Семейный — 9 000 руб./сутки"));

        JButton bookingButton = makeButton("Оформить бронирование");
        bookingButton.addActionListener((ActionEvent e) ->
                showMessage("Бронирование", "Демонстрационный режим.\\Для оформления бронирования обратитесь к администратору гостиницы."));

        JButton servicesButton = makeButton("Услуги");
        servicesButton.addActionListener((ActionEvent e) ->
                showMessage("Дополнительные услуги", "Завтрак — 800 руб.\\Трансфер — 1 500 руб."));

        JButton animationButton = makeButton("Ускорить анимацию");
        animationButton.addActionListener((ActionEvent e) -> {
            scenePanel.speedUp();
            statusLabel.setText("Скорость анимации увеличена.");
        });

        buttons.add(roomsButton);
        buttons.add(bookingButton);
        buttons.add(servicesButton);
        buttons.add(animationButton);
        bottom.add(buttons, BorderLayout.CENTER);

        statusLabel.setForeground(new Color(47, 62, 80));
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        bottom.add(statusLabel, BorderLayout.SOUTH);
        root.add(bottom, BorderLayout.SOUTH);

        setContentPane(root);
    }

    private JButton makeButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
        button.setForeground(new Color(26, 42, 60));
        button.setBackground(new Color(245, 213, 148));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(218, 183, 116)),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)));
        return button;
    }

    private void showMessage(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
        statusLabel.setText("Открыт раздел: " + title + ".");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HotelComfort().setVisible(true));
    }

    private static class Snowflake {
        double x, y, speed, size;
        Snowflake(double x, double y, double speed, double size) {
            this.x = x; this.y = y; this.speed = speed; this.size = size;
        }
    }

    private static class ScenePanel extends JPanel {
        private final Random random = new Random();
        private final List<Snowflake> snow = new ArrayList<>();
        private double suitcaseX = -150;
        private double suitcaseSpeed = 2.0;
        private int tick = 0;

        ScenePanel() {
            setBackground(new Color(30, 55, 78));
            for (int i = 0; i < 95; i++) {
                snow.add(new Snowflake(random.nextInt(1200), random.nextInt(600),
                        0.7 + random.nextDouble() * 2.0, 2 + random.nextDouble() * 4));
            }
            Timer timer = new Timer(30, e -> {
                tick++;
                for (Snowflake flake : snow) {
                    flake.y += flake.speed;
                    flake.x += Math.sin((tick + flake.y) / 35.0) * 0.45;
                    if (flake.y > getHeight()) {
                        flake.y = -5;
                        flake.x = random.nextInt(Math.max(1, getWidth()));
                    }
                }
                suitcaseX += suitcaseSpeed;
                if (suitcaseX > getWidth() + 30) suitcaseX = -150;
                repaint();
            });
            timer.start();
        }

        void speedUp() {
            suitcaseSpeed = Math.min(suitcaseSpeed + 1.0, 8.0);
            for (Snowflake flake : snow) flake.speed = Math.min(flake.speed + 0.2, 5.0);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();

            // Ночное зимнее небо
            g.setPaint(new GradientPaint(0, 0, new Color(26, 49, 75), 0, h, new Color(105, 139, 163)));
            g.fillRect(0, 0, w, h);

            // Луна
            g.setColor(new Color(255, 238, 190));
            g.fillOval(w - 150, 35, 62, 62);

            // Дальний силуэт города
            g.setColor(new Color(45, 66, 84));
            for (int i = 0; i < w; i += 65) {
                int bh = 55 + (i * 17 % 85);
                g.fillRect(i, h - 165 - bh, 48, bh);
                g.setColor(new Color(238, 205, 127, 170));
                for (int yy = h - 155 - bh; yy < h - 175; yy += 22) {
                    g.fillRect(i + 9, yy, 7, 10);
                    g.fillRect(i + 27, yy, 7, 10);
                }
                g.setColor(new Color(45, 66, 84));
            }

            // Здание гостиницы
            int hotelW = Math.min(420, w - 100);
            int hotelX = (w - hotelW) / 2;
            int hotelY = h - 300;
            g.setColor(new Color(224, 220, 207));
            g.fillRoundRect(hotelX, hotelY, hotelW, 250, 12, 12);
            g.setColor(new Color(39, 62, 83));
            g.fillRect(hotelX + 18, hotelY + 20, hotelW - 36, 56);

            // Самодельный логотип
            g.setColor(new Color(245, 213, 148));
            int cx = w / 2;
            g.fillOval(cx - 17, hotelY + 31, 34, 34);
            g.setColor(new Color(39, 62, 83));
            g.fillOval(cx - 9, hotelY + 39, 18, 18);
            g.setColor(new Color(245, 213, 148));
            g.setFont(new Font("Serif", Font.BOLD, 22));
            String title = "HOTEL COMFORT";
            FontMetrics fm = g.getFontMetrics();
            g.drawString(title, cx - fm.stringWidth(title) / 2, hotelY + 104);

            // Окна
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 7; col++) {
                    int xx = hotelX + 28 + col * ((hotelW - 65) / 7);
                    int yy = hotelY + 125 + row * 38;
                    g.setColor((row + col + tick / 25) % 5 == 0
                            ? new Color(255, 221, 139) : new Color(76, 112, 137));
                    g.fillRoundRect(xx, yy, 24, 22, 4, 4);
                }
            }

            // Вход и дорожка
            g.setColor(new Color(44, 63, 79));
            g.fillRoundRect(cx - 28, hotelY + 174, 56, 76, 8, 8);
            g.setColor(new Color(245, 213, 148));
            g.fillOval(cx + 12, hotelY + 208, 5, 5);
            g.setColor(new Color(215, 224, 228));
            int[] px = {cx - 55, cx + 55, cx + 150, cx - 150};
            int[] py = {h - 50, h - 50, h, h};
            g.fillPolygon(px, py, 4);

            // Снег на переднем плане
            g.setColor(new Color(241, 247, 250));
            g.fillRect(0, h - 48, w, 48);

            // Снегопад
            for (Snowflake flake : snow) {
                g.setColor(new Color(255, 255, 255, 220));
                g.fillOval((int) flake.x, (int) flake.y, (int) flake.size, (int) flake.size);
            }

            // Движущийся чемодан — анимированный объект
            int bx = (int) suitcaseX;
            int by = h - 95;
            g.setColor(new Color(31, 43, 57));
            g.setStroke(new BasicStroke(4));
            g.drawRoundRect(bx + 25, by - 15, 32, 18, 7, 7);
            g.setColor(new Color(189, 79, 67));
            g.fillRoundRect(bx, by, 82, 57, 12, 12);
            g.setColor(new Color(245, 213, 148));
            g.setStroke(new BasicStroke(3));
            g.drawLine(bx + 17, by + 7, bx + 17, by + 48);
            g.drawLine(bx + 65, by + 7, bx + 65, by + 48);
            g.setColor(new Color(35, 45, 55));
            g.fillOval(bx + 12, by + 51, 15, 15);
            g.fillOval(bx + 57, by + 51, 15, 15);

            g.dispose();
        }
    }
}
